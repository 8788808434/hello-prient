package com.example.DonBooking;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DonBookingApplication {

	public static void main(String[] args) {
		SpringApplication.run(DonBookingApplication.class, args);
	}

}
