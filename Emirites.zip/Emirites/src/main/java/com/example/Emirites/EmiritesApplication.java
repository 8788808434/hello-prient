package com.example.Emirites;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmiritesApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmiritesApplication.class, args);
	}

}
