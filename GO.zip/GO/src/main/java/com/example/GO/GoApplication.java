package com.example.GO;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GoApplication {

	public static void main(String[] args) {
		SpringApplication.run(GoApplication.class, args);
	}

}
